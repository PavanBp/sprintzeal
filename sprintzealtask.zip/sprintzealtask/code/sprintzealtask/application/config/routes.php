<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//home
$route['default_controller'] = 'employment/employee/Employee/addEmployee';
$route['index'] = 'employment/employee/Employee/addEmployee';
//home

//employee
$route['employee/add-employee'] = 'employment/employee/Employee/addEmployee';
$route['employee/insert-employee'] = 'employment/employee/Employee/insertEmployee';
$route['employee/all-employees'] = 'employment/employee/Employee/allEmployees';
$route['employee/all-employees/(:any)'] = 'employment/employee/Employee/allEmployees';
$route['employee/edit-employee/:num'] = 'employment/employee/Employee/editEmployee';
$route['employee/update-employee'] = 'employment/employee/Employee/updateEmployee';
$route['employee/delete-employee'] = 'employment/employee/Employee/deleteEmployee';
//employee

//employee details
$route['employee-details/add-employee-details'] = 'employment/employee-details/Employee_details/addEmployeeDetails';
$route['employee-details/insert-employee-details'] = 'employment/employee-details/Employee_details/insertEmployeeDetails';
$route['employee-details/all-employee-details'] = 'employment/employee-details/Employee_details/allEmployeeDetails';
$route['resume/edit-resume/:num'] = 'employment/employee-details/Employee_details/editEmployeeDetails';
$route['degree-certificate/edit-degree-certificate/:num'] = 'employment/employee-details/Employee_details/editEmployeeDetails';
$route['passport-copy/edit-passport-copy/:num'] = 'employment/employee-details/Employee_details/editEmployeeDetails';
$route['update/update-document'] = 'employment/employee-details/Employee_details/updateEmployeeDetails';
$route['employee-details/delete-data'] = 'employment/employee-details/Employee_details/deleteEmployeeDetails';

//download documents
$route['resume/download-resume/:num'] = 'employment/employee-details/Employee_details/download_document';
$route['degree-certificate/download-degree-certificate/:num'] = 'employment/employee-details/Employee_details/download_document';
$route['passport-copy/download-passport-copy/:num'] = 'employment/employee-details/Employee_details/download_document';
//download documents

//view documents
$route['resume/view-resume/:num'] = 'employment/employee-details/Employee_details/view_document';
$route['degree-certificate/view-degree-certificate/:num'] = 'employment/employee-details/Employee_details/view_document';
$route['passport-copy/view-passport-copy/:num'] = 'employment/employee-details/Employee_details/view_document';
//view documents

//employee details
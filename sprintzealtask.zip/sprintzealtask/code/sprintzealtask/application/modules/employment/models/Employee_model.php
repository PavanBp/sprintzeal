<?php
class Employee_model extends CI_Model{
		
		//function to insert the data
		public function insert($data,$table){
			$query = $this->db->insert($table,$data);
			return $this->db->affected_rows();
		}
		
		//function to update the data
		public function updateData($table,$data,$condition){
			$this->db->where($condition);
			$this->db->update($table,$data);
			return $this->db->affected_rows();
		}
		
		//function to delete the data
		public function deleteData($table,$condition){
			$query = $this->db->query("DELETE FROM ".$table."".$condition.";");
			//echo $this->db->last_query();exit;
			return $this->db->affected_rows();
		}
		
		//function to read the data
		public function readData($table,$columns,$condition){
			$query = $this->db->query("SELECT ".$columns." FROM ".$table."".$condition.";");
			return $query->result();
		}
		
		//function to delete the image
		public function deleteImage($id,$columnName1,$columnName2,$table){
			$query = $this->db->update($table,array($columnName1 => ""),array($columnName2=>$id));
		}
		
}

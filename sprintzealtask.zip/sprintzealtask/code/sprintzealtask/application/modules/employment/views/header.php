<!doctype html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SPRINTZEAL TASK</title>
    <meta name="description" content="SPRINTZEAL TASK">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo SITE_URL ?>favicon.ico">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo SITE_URL ?>assets/design-related/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL ?>assets/design-related/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL ?>assets/design-related/scss/style.css">
	<script type="text/javascript" src="<?php echo SITE_URL ?>assets/design-related/js/jquery.min.js"></script>
</head>
<body>
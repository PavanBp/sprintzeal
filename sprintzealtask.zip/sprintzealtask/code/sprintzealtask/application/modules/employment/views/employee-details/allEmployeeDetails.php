        <style>
			#bootstrap-data-table_wrapper {
				padding: 25px !important;
				overflow: auto;
			}
			
			.fa-trash{
				cursor: pointer;
			}
		</style>
		
        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Employee Details</strong>
							<?php if($this->session->flashdata('msg')) {echo $this->session->flashdata('msg');} ?>
                        </div>
                        <div class="card-body">
                  <table id="bootstrap-data-table" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>Employee</th>
						<th>Resume</th>
						<th>Degree Certificate</th>
						<th>Passport Copy</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php if($allEmployeeDetails != false){
						foreach($allEmployeeDetails as $value){ ?>
                      <tr>
                        <td><?php echo $value->name; ?></td>
						<td>
							<?php if($value->resume != ""){ ?>
							<a target="_blank" href="<?php echo SITE_URL.'resume/view-resume';?>/<?php if(isset($value->employee_details_id)){echo $value->employee_details_id;} ?>">
								<i title="View resume" class="fa fa-eye" aria-hidden="true"></i>
							</a>
							<a href="<?php echo SITE_URL.'resume/download-resume';?>/<?php if(isset($value->employee_details_id)){echo $value->employee_details_id;} ?>">
								<i title="Download resume" class="fa fa-download" aria-hidden="true"></i>
							</a>
							<a href="<?php echo SITE_URL.'resume/edit-resume'; ?>/<?php echo $value->employee_details_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
							<i data-toggle="modal" data-target="#deleteModal" data-type="single" data-resume="<?php echo $value->resume;?>" data-degree="" data-passport="" data-id="<?php echo $value->employee_details_id;?>" class="fa fa-trash deleteEmployeeDetails" aria-hidden="true"></i>
							<?php }else { ?>
								NA <a href="<?php echo SITE_URL.'resume/edit-resume'; ?>/<?php echo $value->employee_details_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
							<?php } ?>
						</td>
						<td>
							<?php if($value->degree_certificate != ""){ ?>
							<a target="_blank" href="<?php echo SITE_URL.'degree-certificate/view-degree-certificate';?>/<?php if(isset($value->employee_details_id)){echo $value->employee_details_id;} ?>">
								<i title="View degree certificate" class="fa fa-eye" aria-hidden="true"></i>
							</a>
							<a href="<?php echo SITE_URL.'degree-certificate/download-degree-certificate';?>/<?php if(isset($value->employee_details_id)){echo $value->employee_details_id;} ?>">
								<i title="Download degree certificate" class="fa fa-download" aria-hidden="true"></i>
							</a>
							<a href="<?php echo SITE_URL.'degree-certificate/edit-degree-certificate'; ?>/<?php echo $value->employee_details_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
							<i data-toggle="modal" data-target="#deleteModal" data-type="single" data-resume="" data-degree="<?php echo $value->degree_certificate;?>" data-passport="" data-id="<?php echo $value->employee_details_id;?>" class="fa fa-trash deleteEmployeeDetails" aria-hidden="true"></i>
							<?php }else { ?>
								NA <a href="<?php echo SITE_URL.'degree-certificate/edit-degree-certificate'; ?>/<?php echo $value->employee_details_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
							<?php } ?>
						</td>
						<td>
							<?php if($value->passport_copy != ""){ ?>
							<a target="_blank" href="<?php echo SITE_URL.'passport-copy/view-passport-copy';?>/<?php if(isset($value->employee_details_id)){echo $value->employee_details_id;} ?>">
								<i title="View passport copy" class="fa fa-eye" aria-hidden="true"></i>
							</a>
							<a href="<?php echo SITE_URL.'passport-copy/download-passport-copy';?>/<?php if(isset($value->employee_details_id)){echo $value->employee_details_id;} ?>">
								<i title="Download passport copy" class="fa fa-download" aria-hidden="true"></i>
							</a>
							<a href="<?php echo SITE_URL.'passport-copy/edit-passport-copy'; ?>/<?php echo $value->employee_details_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
							<i data-toggle="modal" data-target="#deleteModal" data-type="single" data-resume="" data-degree="" data-passport="<?php echo $value->passport_copy;?>" data-id="<?php echo $value->employee_details_id;?>" class="fa fa-trash deleteEmployeeDetails" aria-hidden="true"></i>
							<?php }else { ?>
								NA <a href="<?php echo SITE_URL.'passport-copy/edit-passport-copy'; ?>/<?php echo $value->employee_details_id; ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
							<?php } ?>
						</td>
						<td><i data-toggle="modal" data-target="#deleteModal" data-type="all" data-resume="<?php echo $value->resume;?>" data-degree="<?php echo $value->degree_certificate;?>" data-passport="<?php echo $value->passport_copy;?>" data-id="<?php echo $value->employee_details_id;?>" class="fa fa-trash deleteEmployeeDetails" aria-hidden="true"></i></td>
                      </tr>
					<?php } } ?>
                    </tbody>
                  </table>
                        </div>
                    </div>
                </div>
               </div>
            </div>
		
		<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true" data-backdrop="static">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
							<div class="modal-body">
								<div class="text-center">Are you sure you want to delete this data?</div>
							</div>
							<form name="" action="<?php echo SITE_URL.'employee-details/delete-data';?>" method="post">
								<div id="deleteEmployeeDetails"></div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
									<button type="submit" class="btn btn-primary">Confirm</button>
								</div>
							</form>
                        </div>
                    </div>
         </div>
		 
    </div><!-- /#right-panel -->

    <script src="<?php echo SITE_URL ?>assets/design-related/js/products.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/popper.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/plugins.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/main.js"></script>

    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/datatables.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/jszip.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/pdfmake.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/vfs_fonts.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/buttons.print.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/lib/data-table/datatables-init.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
		
          $('#bootstrap-data-table-export').DataTable();
			
		  $(".deleteEmployeeDetails").on('click',function(){
			$('#deleteEmployeeDetails').html('<input type="hidden" name="type" value="'+ $(this).data('type')+'" /><input type="hidden" name="employee_details_id" value="'+ $(this).data('id')+'" /><input type="hidden" name="resume" value="'+ $(this).data('resume')+'"/><input type="hidden" name="degree_certificate" value="'+ $(this).data('degree')+'"/><input type="hidden" name="passport_copy" value="'+ $(this).data('passport')+'"/>');
		  });	

        });
    </script>

</body>
</html>

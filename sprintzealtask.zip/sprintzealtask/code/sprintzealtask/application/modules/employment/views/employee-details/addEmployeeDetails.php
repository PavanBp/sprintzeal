        <div class="content mt-12">
            <div class="animated fadeIn">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <strong>Add employee details</strong>
                      </div>
                      <div class="card-body card-block">
                        <form name="" action="<?php echo SITE_URL.'employee-details/insert-employee-details';?>" method="post" class="form-horizontal" enctype="multipart/form-data">
						  <?php if($this->session->flashdata('msg')) {echo $this->session->flashdata('msg');} ?>
						  <div class="row form-group"> 
							<div class="col col-md-2"><label for="emp_id" class=" form-control-label">Employee</label></div>
								<div class="col col-md-8 card-body">
								  <select name="emp_id" id="emp_id" class="form-control" tabindex="1" required>
									<option value="">Select employee</option>
									<?php foreach($employee as $value){?>
									<option value="<?php echo $value->emp_id;?>"><?php echo $value->name;?> (<?php echo $value->designation;?>)</option>
									<?php } ?>
								  </select>
								</div>
						  </div>
						  <div class="row form-group">
							<div class="col col-md-2"><label for="resume" class=" form-control-label">Resume</label></div>
							<div class="col col-md-8 card-body">
							  <input accept=".doc,.docx,.pdf,.xls,.xlsx" type="file" id="resume" name="resume" class="form-control" title="Upload resume" required>
							</div>
						  </div>
						  <div class="row form-group">
							<div class="col col-md-2"><label for="degree_certificate" class=" form-control-label">Degree certificate</label></div>
							<div class="col col-md-8 card-body">
							  <input accept=".doc,.docx,.pdf,.xls,.xlsx" type="file" id="degree_certificate" name="degree_certificate" class="form-control" title="Upload degree certificate" required>
							</div>
						  </div>
						  <div class="row form-group">
							<div class="col col-md-2"><label for="passport_copy" class=" form-control-label">Passport Copy</label></div>
							<div class="col col-md-8 card-body">
							  <input accept=".doc,.docx,.pdf,.xls,.xlsx" type="file" id="passport_copy" name="passport_copy" class="form-control" title="Upload passport copy" required>
							</div>
						  </div>
						  <div class="row form-group">
						    <div class="col-md-2 col-12"></div>
						    <div class="col-12 col-md-1">
								<button type="submit" class="btn btn-primary btn-sm submit">Submit</button>
						    </div>
						  </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
		
	<script src="<?php echo SITE_URL ?>assets/design-related/js/products.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/popper.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/plugins.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/main.js"></script>
	<script src="<?php echo SITE_URL ?>assets/design-related/js/lib/chosen/chosen.jquery.min.js"></script>
</body>
</html>

		<div class="content mt-12">
            <div class="animated fadeIn">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <strong>Edit employee</strong>
                      </div>
                      <div class="card-body card-block">
                        <form action="<?php echo SITE_URL.'employee/update-employee';?>" method="post" class="form-horizontal" enctype="multipart/form-data">
						  <?php if($this->session->flashdata('msg')) {echo $this->session->flashdata('msg');} ?>
							  <input type="hidden" name="url" value="<?php echo $this->uri->uri_string;?>">
							  <input type="hidden" name="emp_id" value="<?php if(isset($editEmployee[0]->emp_id)){echo $editEmployee[0]->emp_id;} ?>">
							  <div class="row form-group"> 
								<div class="col col-md-2"><label for="title" class="form-control-label">Name</label></div>
								<div class="col col-md-8 card-body">
								  <input type="text" value="<?php if(isset($editEmployee[0]->name)){echo $editEmployee[0]->name;} ?>" name="name" id="name" placeholder="Name" class="form-control" required/>
							    </div>
							  </div>
							  <div class="row form-group"> 
								<div class="col col-md-2"><label for="title" class="form-control-label">Email</label></div>
								<div class="col col-md-8 card-body">
								  <input type="email" value="<?php if(isset($editEmployee[0]->email)){echo $editEmployee[0]->email;} ?>" name="email" id="email" placeholder="Name" class="form-control" required/>
							    </div>
							  </div>
							  <div class="row form-group"> 
								<div class="col col-md-2"><label for="title" class="form-control-label">Designation</label></div>
								<div class="col col-md-8 card-body">
								  <input type="text" value="<?php if(isset($editEmployee[0]->designation)){echo $editEmployee[0]->designation;} ?>" name="designation" id="designation" placeholder="Designation" class="form-control" required/>
							    </div>
							  </div>
							  <div class="row form-group">
								<div class="col-md-2 col-12"></div>
								<div class="col-12 col-md-1">
									<button type="submit" class="btn btn-primary btn-sm submit">Submit</button>
								</div>
							  </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
		
	<script src="<?php echo SITE_URL ?>assets/design-related/js/products.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/popper.min.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/plugins.js"></script>
    <script src="<?php echo SITE_URL ?>assets/design-related/js/main.js"></script>
	<script src="<?php echo SITE_URL ?>assets/design-related/js/lib/chosen/chosen.jquery.min.js"></script>
</body>
</html>

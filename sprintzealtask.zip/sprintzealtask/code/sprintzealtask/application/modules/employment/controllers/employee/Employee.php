<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends MX_Controller {
	
	public function addEmployee(){
		$this->load->model('Employee_model');
		$this->load->view('header');
		$this->load->view('sideNavBar');
		$this->load->view('employee/addEmployee');
	}
	
	public function insertEmployee(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('designation', 'Designation', 'trim|required');
		if($this->form_validation->run() == FALSE){
			$error = validation_errors();
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">'.$error.'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect(SITE_URL.'employee/add-employee');
        }		
		
		$this->load->model('Employee_model');
		date_default_timezone_set("Asia/Kolkata");
		$table = "employee";
		$data = array(
			'name'       		=> $this->input->post('name',true),
			'email'   			=> $this->input->post('email',true),
			'designation'   	=> $this->input->post('designation',true)
		);
		$insert_employee = $this->Employee_model->insert($data,$table);
		if($insert_employee == 1 ){
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
											<span class="badge badge-pill badge-primary">Success</span>
												You have successfully added the data.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');						
		}else{
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Danger</span>
												Failed to add the data. Please try again.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');	
		}
		redirect(SITE_URL.'employee/add-employee');
	}
	
	public function allEmployees(){
		$this->load->model('Employee_model');
		$table = "employee";
		$columns = "emp_id,name,email,designation";
		$condition = "";
		$data['employees'] = $this->Employee_model->readData($table,$columns,$condition);
		$this->load->view('header');
		$this->load->view('sideNavBar');
		$this->load->view('employee/allEmployees',$data);
	}
	
	public function editEmployee(){
		$this->load->model('Employee_model');
		$table = "employee";
		$id = $this->uri->segment(3);
		$columns = "emp_id,name,email,designation";
		$condition = " WHERE emp_id = '".$id."'";
		$data['editEmployee'] = $this->Employee_model->readData($table,$columns,$condition);
		$this->load->view('header');
		$this->load->view('sideNavBar');
		$this->load->view('employee/editEmployee',$data);
	}
	
	public function updateEmployee(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('name', 'Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('designation', 'Designation', 'trim|required');
		if($this->form_validation->run() == FALSE){
			$error = validation_errors();
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">'.$error.'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect(SITE_URL.$this->input->post('url'),'refresh');exit;
        }
		$this->load->model('Employee_model');
		date_default_timezone_set("Asia/Kolkata");
		$table = "employee";
		$id = $this->input->post('emp_id');
		$data = array(
			'name'       		=> $this->input->post('name',true),
			'email'   			=> $this->input->post('email',true),
			'designation'   	=> $this->input->post('designation',true)
		);
		$condition = array('emp_id' => $id);
		$updateEmployee = $this->Employee_model->updateData($table,$data,$condition);
		if($updateEmployee == 1 ){
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
											<span class="badge badge-pill badge-primary">Success</span>
												You have successfully edited the data.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');						
		}else if($updateEmployee == 0 ){
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Danger</span>
												You cannot update the same data. Before updating, please make any necessary changes to the data.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');
		}else{
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Danger</span>
												Failed to edit the data. Please try again.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');	
		}
		redirect(SITE_URL.$this->input->post('url'),'refresh');exit;
	}
	
	public function deleteEmployee(){
		$id = $this->input->post('id');
		$this->load->model('Employee_model');
		$table = "employee";
		if($id != ""){
			$condition = " WHERE emp_id = '".$id."'";
			$delete_employee = $this->Employee_model->deleteData($table,$condition);
			if($delete_employee == 1){
				$table = "employee_details";
				$columns = "resume,degree_certificate,passport_copy";
				$condition = " WHERE employee_details_id = '".$id."'";
				$existing_documents = $this->Employee_model->readData($table,$columns,$condition);
				$resume = $existing_documents[0]->resume;
				$degree_certificate = $existing_documents[0]->degree_certificate;
				$passport_copy = $existing_documents[0]->passport_copy;
				if($resume != "" && $id != ""){
					unlink('./assets/employee_resume/'.$resume);
				}
				if($degree_certificate != "" && $id != ""){
					unlink('./assets/employee_degree_certificate/'.$degree_certificate);
				}
				if($passport_copy != "" && $id != ""){
					unlink('./assets/employee_passport_copy/'.$passport_copy);
				}
				$condition = " WHERE employee_details_id = ".$id."";
				$deleteEmployeeDetails = $this->Employee_model->deleteData($table,$condition);
			}
			if($delete_employee == 1 && $deleteEmployeeDetails == 1){
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
												<span class="badge badge-pill badge-primary">Success</span>
													You have successfully deleted the data.
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
											</div>');
			}else{
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
												<span class="badge badge-pill badge-danger">Danger</span>
													Failed to delete the data. Please try again.
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
											</div>');
			}
			redirect(SITE_URL.'employee/all-employees/');
		}
	}
}
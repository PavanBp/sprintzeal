<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_details extends MX_Controller {
	
	public function addEmployeeDetails(){
		$this->load->model('Employee_model');
		$data = "";
		$table = "employee";
		$columns = "emp_id,name,email,designation";
		$condition = "";
		$employees = $this->Employee_model->readData($table,$columns,$condition);
		
		$table = "employee_details";
		$columns = "emp_id";
		$condition = "";
		$existing_employees = $this->Employee_model->readData($table,$columns,$condition);
		
		foreach($existing_employees as $employee){
			$existing_employee[] = $employee->emp_id;
		}
		
		foreach($employees as $value){
			if(!empty($existing_employee) && !in_array($value->emp_id, $existing_employee)){
				$data['employee'][] = $value;
			}
		}
		//echo'<pre>';print_r($existing_employees);exit;
		
		if(is_string($data) && $data == ""){
			$data['employee'] = $employees;
		}
		//echo'<pre>';print_r($data);exit;
		$this->load->view('header');
		$this->load->view('sideNavBar');
		$this->load->view('employee-details/addEmployeeDetails',$data);
	}
	
	public function insertEmployeeDetails(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('emp_id', 'employee', 'trim|required');
		if($_FILES["resume"]["name"] == ""){
			$this->form_validation->set_rules('resume', 'resume', 'trim|required');
		}
		if($_FILES["degree_certificate"]["name"] == ""){
			$this->form_validation->set_rules('degree_certificate', 'degree certificate', 'trim|required');
		}
		if($_FILES["passport_copy"]["name"] == ""){
			$this->form_validation->set_rules('passport_copy', 'passport copy', 'trim|required');
		}
		if($this->form_validation->run() == FALSE){
			$error = validation_errors();
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">'.$error.'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect(SITE_URL.'employee-details/add-employee-details');exit;
        }
		$this->load->helper('upload_file_helper');
		$allowed_document_types = array("doc", "docx", "pdf", "xls", "xlsx");
		if(isset($_FILES["resume"]["name"]) && $_FILES["resume"]["name"] != "" &&
			isset($_FILES["degree_certificate"]["name"]) && $_FILES["degree_certificate"]["name"] != "" &&
			isset($_FILES["passport_copy"]["name"]) && $_FILES["passport_copy"]["name"] != ""){
			if(isset($_FILES["resume"]["name"]) && $_FILES["resume"]["name"] != ""){
				$resume_details = $_FILES["resume"];
				$resume_path = 'assets/employee_resume/';
				$resume_name = $_FILES["resume"]["name"];
				$upload_resume = upload_document($resume_details,$resume_path,$resume_name,$allowed_document_types);
			}
			if(isset($_FILES["degree_certificate"]["name"]) && $_FILES["degree_certificate"]["name"] != ""){
				$degree_certificate_details = $_FILES["degree_certificate"];
				$degree_certificate_path = 'assets/employee_degree_certificate/';
				$degree_certificate_name = $_FILES["degree_certificate"]["name"];
				$upload_degree_certificate = upload_document($degree_certificate_details,$degree_certificate_path,$degree_certificate_name,$allowed_document_types);
			}
			if(isset($_FILES["passport_copy"]["name"]) && $_FILES["passport_copy"]["name"] != ""){
				$passport_copy_details = $_FILES["passport_copy"];
				$passport_copy_path = 'assets/employee_passport_copy/';
				$passport_copy_name = $_FILES["passport_copy"]["name"];
				$upload_passport_copy = upload_document($passport_copy_details,$passport_copy_path,$passport_copy_name,$allowed_document_types);
			}
			date_default_timezone_set("Asia/Kolkata");
			$this->load->model('Employee_model');
			$data = array(
				'emp_id'       				=> $this->input->post('emp_id',true),
				'resume'         			=> $upload_resume,
				'resume_path'         		=> $resume_path,
				'degree_certificate'       	=> $upload_degree_certificate,
				'degree_certificate_path'   => $degree_certificate_path,
				'passport_copy'   			=> $upload_passport_copy,
				'passport_copy_path'   		=> $passport_copy_path,
				'created_date'    			=> date("Y-m-d")
			);
			$table = "employee_details";
			$insertEmployeeDetails = $this->Employee_model->insert($data,$table);
		}
		if($insertEmployeeDetails == 1 ){
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
											<span class="badge badge-pill badge-primary">Success</span>
												You have successfully added the data.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');						
		}else{
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Danger</span>
												Failed to add the data. Please try again.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');	
		}
		redirect(SITE_URL.'employee-details/add-employee-details');
	}
	
	public function allEmployeeDetails(){
		$this->load->model('Employee_model');
		$table = "employee_details";
		$columns = "employee.name,employee_details.employee_details_id,employee_details.emp_id,employee_details.resume,employee_details.resume_path,employee_details.degree_certificate,employee_details.degree_certificate_path,employee_details.passport_copy,employee_details.passport_copy_path";
		$condition = " JOIN employee ON employee.emp_id=employee_details.emp_id;";
		$data['allEmployeeDetails'] = $this->Employee_model->readData($table,$columns,$condition);
		$this->load->view('header');
		$this->load->view('sideNavBar');
		$this->load->view('employee-details/allEmployeeDetails',$data);
	}
	
	public function editEmployeeDetails(){
		$this->load->model('Employee_model');
		$id = $this->uri->segment(3);
		$table = "employee_details";
		$columns = "employee.name,employee_details.employee_details_id,employee_details.resume,employee_details.degree_certificate,employee_details.passport_copy";
		$condition = " JOIN employee ON employee.emp_id=employee_details.emp_id WHERE employee_details_id = '".$id."'";
		$data['editEmployeeDetails'] = $this->Employee_model->readData($table,$columns,$condition);
		$this->load->view('header');
		$this->load->view('sideNavBar');
		$this->load->view('employee-details/editEmployeeDetails',$data);
	}
	
	public function updateEmployeeDetails(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('employee_details_id', 'employee', 'trim|required');
		if(isset($_FILES["resume"]["name"])){
			if($_FILES["resume"]["name"] == ""){
				$this->form_validation->set_rules('resume', 'resume', 'trim|required');
			}
		}
		if(isset($_FILES["degree_certificate"]["name"])){
			if($_FILES["degree_certificate"]["name"] == ""){
				$this->form_validation->set_rules('degree_certificate', 'degree certificate', 'trim|required');
			}
		}
		if(isset($_FILES["passport_copy"]["name"])){
			if($_FILES["passport_copy"]["name"] == ""){
				$this->form_validation->set_rules('passport_copy', 'passport copy', 'trim|required');
			}
		}
		if($this->form_validation->run() == FALSE){
			$error = validation_errors();
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">'.$error.'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect(SITE_URL.$this->input->post('url'),'refresh');exit;
        }
		
		$this->load->model('Employee_model');
		$table = "employee_details";
		$id = $this->input->post('employee_details_id');
		$columns = "resume,degree_certificate,passport_copy";
		$condition = " WHERE employee_details_id = '".$id."'";
		$existing_documents = $this->Employee_model->readData($table,$columns,$condition);
		
		$data = "";
		if(isset($_FILES["resume"]["name"])){
			$existing_resume = $existing_documents[0]->resume;
			if($existing_resume != "" && $id != ""){
				unlink('./assets/employee_resume/'.$existing_resume);
				$data = array(
					'resume'      			=> ""
				);
			}
		}
		if(isset($_FILES["degree_certificate"]["name"])){
			$existing_degree_certificate = $existing_documents[0]->degree_certificate;
			if($existing_degree_certificate != "" && $id != ""){
				unlink('./assets/employee_degree_certificate/'.$existing_degree_certificate);
				$data = array(
					'degree_certificate'    => ""
				);
			}
		}
		if(isset($_FILES["passport_copy"]["name"])){
			$existing_passport_copy = $existing_documents[0]->passport_copy;
			if($existing_passport_copy != "" && $id != ""){
				unlink('./assets/employee_passport_copy/'.$existing_passport_copy);
				$data = array(
					'passport_copy'      	=> ""
				);
			}
		}
		$condition = array('employee_details_id' => $id);
		if($data != ""){
			$deleteEmployeeDetails = $this->Employee_model->updateData($table,$data,$condition);
		}
		
		$this->load->helper('upload_file_helper');
		$allowed_document_types = array("doc", "docx", "pdf", "xls", "xlsx");
		if(isset($_FILES["resume"]["name"]) && $_FILES["resume"]["name"] != ""){
			$resume_details = $_FILES["resume"];
			$resume_path = 'assets/employee_resume/';
			$resume_name = $_FILES["resume"]["name"];
			$upload_resume = upload_document($resume_details,$resume_path,$resume_name,$allowed_document_types);
			$data = array(
				'resume'      			=> 		$upload_resume
			);
		}
		if(isset($_FILES["degree_certificate"]["name"]) && $_FILES["degree_certificate"]["name"] != ""){
			$degree_certificate_details = $_FILES["degree_certificate"];
			$degree_certificate_path = 'assets/employee_degree_certificate/';
			$degree_certificate_name = $_FILES["degree_certificate"]["name"];
			$upload_degree_certificate = upload_document($degree_certificate_details,$degree_certificate_path,$degree_certificate_name,$allowed_document_types);
			$data = array(
				'degree_certificate'    => 		$upload_degree_certificate
			);
		}
		if(isset($_FILES["passport_copy"]["name"]) && $_FILES["passport_copy"]["name"] != ""){
			$passport_copy_details = $_FILES["passport_copy"];
			$passport_copy_path = 'assets/employee_passport_copy/';
			$passport_copy_name = $_FILES["passport_copy"]["name"];
			$upload_passport_copy = upload_document($passport_copy_details,$passport_copy_path,$passport_copy_name,$allowed_document_types);
			$data = array(
				'passport_copy'      	=> 		$upload_passport_copy
			);
		}
		$table = "employee_details";
		$updateEmployeeDetails = $this->Employee_model->updateData($table,$data,$condition);
		
		if(isset($updateEmployeeDetails) && $updateEmployeeDetails == 1 ){
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
											<span class="badge badge-pill badge-primary">Success</span>
												You have successfully edited the data.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');						
		}else{
			$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Danger</span>
												Failed to edit the data. Please try again.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');
		}
		redirect(SITE_URL.$this->input->post('url'),'refresh');exit;
	}
	
	public function deleteEmployeeDetails(){
		$id = $this->input->post('employee_details_id');
		$type = $this->input->post('type');
		$resume = $this->input->post('resume');
		$degree_certificate = $this->input->post('degree_certificate');
		$passport_copy = $this->input->post('passport_copy');
		$this->load->model('Employee_model');
		$table = "employee_details";
		//echo'<pre>';print_r($_POST);exit;
		if($type == "all"){
			if($resume != "" && $id != ""){
				unlink('./assets/employee_resume/'.$resume);
			}
			if($degree_certificate != "" && $id != ""){
				unlink('./assets/employee_degree_certificate/'.$degree_certificate);
			}
			if($passport_copy != "" && $id != ""){
				unlink('./assets/employee_passport_copy/'.$passport_copy);
			}
			$condition = " WHERE employee_details_id = ".$id."";
			$deleteEmployeeDetails = $this->Employee_model->deleteData($table,$condition);
		}
		if($type == "single"){
			if($resume != "" && $id != ""){
				unlink('./assets/employee_resume/'.$resume);
				$data = array(
					'resume'      			=> ""
				);
			}
			if($degree_certificate != "" && $id != ""){
				unlink('./assets/employee_degree_certificate/'.$degree_certificate);
				$data = array(
					'degree_certificate'    => ""
				);
			}
			if($passport_copy != "" && $id != ""){
				unlink('./assets/employee_passport_copy/'.$passport_copy);
				$data = array(
					'passport_copy'      	=> ""
				);
			}
			$condition = array('employee_details_id' => $id);
			$deleteEmployeeDetails = $this->Employee_model->updateData($table,$data,$condition);
		}
		if($deleteEmployeeDetails == 1 ){
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
											<span class="badge badge-pill badge-primary">Success</span>
												You have successfully deleted the data.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');
		}else{
		$this->session->set_flashdata('msg','<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Danger</span>
												Failed to delete the data. Please try again.
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>');
		}
		redirect(SITE_URL.'employee-details/all-employee-details');
	}

	public function download_document(){
		$this->load->model('Employee_model');
		$table = "employee_details";
		$id = $this->uri->segment(3);
		if($this->uri->segment(1) == "resume"){
			$columns = "resume";
		}
		if($this->uri->segment(1) == "degree-certificate"){
			$columns = "degree_certificate";
		}
		if($this->uri->segment(1) == "passport-copy"){
			$columns = "passport_copy";
		}
		$condition = " WHERE employee_details_id = ".$id."";
		$data['document'] = $this->Employee_model->readData($table,$columns,$condition);
		if(isset($data['document'][0]->resume) && $data['document'][0]->resume != ""){
			$document_name = $data['document'][0]->resume;
		}
		if(isset($data['document'][0]->degree_certificate) && $data['document'][0]->degree_certificate != ""){
			$document_name = $data['document'][0]->degree_certificate;
		}
		if(isset($data['document'][0]->passport_copy) && $data['document'][0]->passport_copy != ""){
			$document_name = $data['document'][0]->passport_copy;
		}
		if(isset($document_name) && $this->uri->segment(1) == "resume"){
			$document_url = SITE_URL."/assets/employee_resume/".$document_name;
		}
		if(isset($document_name) && $this->uri->segment(1) == "degree-certificate"){
			$document_url = SITE_URL."/assets/employee_degree_certificate/".$document_name;
		}
		if(isset($document_name) && $this->uri->segment(1) == "passport-copy"){
			$document_url = SITE_URL."/assets/employee_passport_copy/".$document_name;
		}
		if(isset($document_name) && isset($document_url)){
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Transfer-Encoding: Binary');
			header('Content-Disposition: attachment; filename="'.$document_name.'"');
			ob_clean();
			flush();
			readfile($document_url); //absolute-url
			exit();	
		}else{
			
		}
	}

	public function view_document(){
		$this->load->model('Employee_model');
		$table = "employee_details";
		$id = $this->uri->segment(3);
		if($this->uri->segment(1) == "resume"){
			$columns = "resume";
		}
		if($this->uri->segment(1) == "degree-certificate"){
			$columns = "degree_certificate";
		}
		if($this->uri->segment(1) == "passport-copy"){
			$columns = "passport_copy";
		}
		$condition = " WHERE employee_details_id = ".$id."";
		$data['document'] = $this->Employee_model->readData($table,$columns,$condition);
		if(isset($data['document'][0]->resume) && $data['document'][0]->resume != ""){
			$document_name = $data['document'][0]->resume;
		}
		if(isset($data['document'][0]->degree_certificate) && $data['document'][0]->degree_certificate != ""){
			$document_name = $data['document'][0]->degree_certificate;
		}
		if(isset($data['document'][0]->passport_copy) && $data['document'][0]->passport_copy != ""){
			$document_name = $data['document'][0]->passport_copy;
		}
		if(isset($document_name) && $this->uri->segment(1) == "resume"){
			$document_url = SITE_URL."/assets/employee_resume/".$document_name;
		}
		if(isset($document_name) && $this->uri->segment(1) == "degree-certificate"){
			$document_url = SITE_URL."/assets/employee_degree_certificate/".$document_name;
		}
		if(isset($document_name) && $this->uri->segment(1) == "passport-copy"){
			$document_url = SITE_URL."/assets/employee_passport_copy/".$document_name;
		}
		if(isset($document_name) && isset($document_url)){
			header('Content-type: application/pdf');
			header('Content-Disposition: inline; filename="' .$document_url. '"'); 
			header('Content-Transfer-Encoding: binary'); 
			header('Accept-Ranges: bytes'); 
			@readfile($document_url);
		}else{
			
		}
	}	
}
<?php
if(!defined('BASEPATH')) exit('No direct script access allowed');

//upload file
if(!function_exists('upload_document')){
	function upload_document($fileDetails,$filePath,$name,$allowedFileTypes){
		$explodedFileName = explode('.',$fileDetails['name']);
		$fileExtension = $explodedFileName[count($explodedFileName)-1];
		$fileName = md5(strtotime(date('Y-m-d H:i:s')).uniqid()).".".$fileExtension;
		$fileSize = $fileDetails['size'];
		$fileTmp = $fileDetails['tmp_name'];
		$fileType = $fileDetails['type'];
		$desiredDirectory = $filePath;
		if(in_array($fileExtension,$allowedFileTypes)){
			if(is_dir($desiredDirectory)== false){
				mkdir($desiredDirectory, 0700);                
			}
			if(is_dir($desiredDirectory.$fileName) == false){
				move_uploaded_file($fileTmp,$filePath.$fileName);
			}else{
				$newDirectory = $filePath.$fileName;
				rename($fileTmp,$newDirectory);
			}
			return $fileName;
		}else if(!in_array($fileExtension,$allowedFileTypes)){
			return false;
		}
	}
}
  
	
  
CREATE DATABASE IF NOT EXISTS `sprintzealtask` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sprintzealtask`;

CREATE TABLE IF NOT EXISTS `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `email` varchar(30) NOT NULL,
  `designation` varchar(50) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

INSERT INTO `employee` (`emp_id`, `name`, `email`, `designation`) VALUES
(1, 'Nithin', 'nithink@gmail.com', 'Product Engineer'),
(2, 'Shiva', 'shival@gmail.com', 'Digital Executive');

CREATE TABLE IF NOT EXISTS `employee_details` (
  `employee_details_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `resume` text NOT NULL,
  `resume_path` text NOT NULL,
  `degree_certificate` text NOT NULL,
  `degree_certificate_path` text NOT NULL,
  `passport_copy` text NOT NULL,
  `passport_copy_path` text NOT NULL,
  `created_date` date NOT NULL,
  PRIMARY KEY (`employee_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

INSERT INTO `employee_details` (`employee_details_id`, `emp_id`, `resume`, `resume_path`, `degree_certificate`, `degree_certificate_path`, `passport_copy`, `passport_copy_path`, `created_date`) VALUES
(1, 1, 'f71074ffb6409881b4f5ed674d16d179.pdf', 'assets/employee_resume/', 'ad3b448e870f9bf624cc77b2b948327e.pdf', 'assets/employee_degree_certificate/', '41a9c8717200e09da9d421aba3c15c6a.pdf', 'assets/employee_passport_copy/', '2023-08-10'),
(2, 2, '625e270757b9528d25a85a8bc7371a46.pdf', 'assets/employee_resume/', '6e6e9a83e28c6cf0f72727576a0568a7.pdf', 'assets/employee_degree_certificate/', 'e007cce76c0da9165b8826336c475b0f.pdf', 'assets/employee_passport_copy/', '2023-08-10');
